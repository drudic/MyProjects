class Project < ApplicationRecord
  validates :name, presence: true

  belongs_to :client, optional: true, counter_cache: true
end
